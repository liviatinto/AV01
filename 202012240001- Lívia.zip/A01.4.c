#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <locale.h>

int main(int argc, char *argv[]) {

    int dia;
    char* dias[7] = { "Domingo", "Segunda", "Terca", "Quarta", "Quinta", "Sexta", "Sabado" };


    printf(" Digite um numero entre 1 e 7 para cada dia da semana: ");
    scanf("%d", &dia);

    if (dia <= 0 || dia >= 8) {
        printf("Numero invalido!");
        return 0;
    }

    if (dia - 1 == 0 || dia - 1 == 6) {
        printf("Final de semana %s", dias[dia - 1]);
    } else {
        printf("Dia da semana %s", dias[dia - 1]);
    }

    return 0;
};
