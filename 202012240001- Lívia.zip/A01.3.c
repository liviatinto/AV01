#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <locale.h>

int main(int argc, char *argv[]) {

    char c, cl;

    printf("Digite uma letra: ");
    scanf("%c", &c);

    cl = tolower(c);

    if (tolower(cl) < 'a' || tolower(cl) > 'z') {
        printf("A opcao digitada nao faz parte do alfabeto");
        return 0;
    }

    switch (cl) {
        case 'a':
        case 'e':
        case 'i':
        case 'o':
        case 'u':
            printf("Vogal");
            break;
        default:
            printf("Consoante");
            break;

    }

    getchar();
    return 0;
};
