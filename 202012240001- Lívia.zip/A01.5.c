#include <stdio.h>
#include <math.h>
#include <locale.h>

int main(int argc, char *argv[])
{

    char y;
    double x, z;

    printf("Numero 1: ");
    scanf("%lf", &x);
    getchar();
    printf("Tipo (* / - +): ");
    scanf("%c", &y);
    printf("Numero 2: ");
    scanf("%lf", &z);

    printf("%.2lf %c %.2lf = ", x, y, z);
    switch (y)
    {
    case '*':
        printf("%.2lf", (x * z));
        break;

    case '/':
        if (x == 0 || z == 0)
        {
            printf("Nao e possivel dividir por 0");
            return 0;
        }
        printf("%.2lf", (x / z));
        break;

    case '-':
        printf("%.2lf", (x - z));
        break;

    case '+':
        printf("%.2lf", (x + z));
        break;
    default:
        printf("Simbolo nao reconhecido!");
        break;
    }

    return 0;
};