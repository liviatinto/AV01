#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <locale.h>

int main(int argc, char *argv[]) {

    double altura, peso, imc;

    printf("Digite sua altura: ");
    scanf("%lf", &altura);

    printf("\nDigite o seu peso: ");
    scanf("%lf", &peso);

    imc = peso / pow(altura, 2);

    printf("\nSeu IMC e: %2.2lf \n\n", imc);

    if (imc < 18){
        printf("Voce esta abaixo do peso precisa ganhar %.2lf \n", 18 - imc);
    } else if (imc >= 18 && imc <= 25 ) {
        printf("Peso ideal %.2lf",imc);
    } else {
        printf("Voce esta acima do peso precisa perder %.2lf \n", imc - 25);
    };

    getchar();
    return 0;
};
